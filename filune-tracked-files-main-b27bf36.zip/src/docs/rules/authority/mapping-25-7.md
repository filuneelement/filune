# 25-7 rev16 운영 승인 및 CS-127 매핑

revision 16은 이 보고서 metadata이다. 표의 `rev 16` 열은 별도 ㉕ 1단계 동결 분석본의 이전 결과를 의미한다. 두 판을 혼동하지 않는다. 아래 상태 설명은 원문 용례이며 런타임 승인 정책이 아니다.

| 문서 상태 | 의미(원문 용례) | 기존 코드 상태와 대응 가능 여부 | 코드 수정 필요 여부 |
| --- | --- | --- | --- |
| 운영자 승인 | 규칙을 운영 기준으로 확정(①·마지막 P1~P3) | auto-approved와 직접 대응 불가: 규칙 승인과 실행별 검토는 다름 | 대응 계약 사람 확인 후 판단; 이번 수정 없음 |
| 적용 | 승인 항목의 문서 적용(①) | 직접 대응 없음 | 검토 필요; 이번 수정 없음 |
| 반영 | 충돌 해결의 문서 반영(③) | 직접 대응 없음 | 검토 필요; 이번 수정 없음 |
| 완료 | ⑩ 완료 조건 충족 | 실행 completeness/auto-approved와 동일하지 않음 | 검토 필요; 이번 수정 없음 |
| 동결 | ㉕ 1단계·C-1~C-9·고객 감정서 보존 | blocked와 동일하지 않음 | 검토 필요; 이번 수정 없음 |
| 보류 | ③ 3번의 구 G-4 이전 상태; 현행 OP-T12로 반영 | review-required/blocked 어느 쪽도 자동 대응 불가 | 현행 보류로 재해석 금지; 이번 수정 없음 |
| 없음 | ⑨ 서비스 판정 영향 운영 기준 미확정 없음 | 모든 실행 auto-approved를 뜻하지 않음 | 실행 승인 정책은 별도 확인 |
| frozen | YAML status | 런타임 세 상태와 다른 metadata | 변경 없음 |

현재 코드 읽기 근거: `src/lib/judgment/types.ts`의 OperatorReview.status = auto-approved / review-required / blocked. `policies/operatorReview.ts`는 REVIEW_POLICY_UNMAPPED일 때 unresolved·blocked를 반환한다. 문서 승인만으로 이 기본값을 바꾸는 mapping은 만들지 않았다. `차단`이라는 상태명은 25-7 원문에 없다.

## ① 운영자 승인 반영 현황

[25-7:6](/workspaces/filune/src/docs/source/25-7_rev16.md:6) ① 운영자 승인 반영 현황
[25-7:7](/workspaces/filune/src/docs/source/25-7_rev16.md:7) 모든 항목을 2026-11-13 운영자 확정 운영 규칙(표시 OP-1113)으로 반영했다. 승인 항목을 다시 질문하거나 변경한 곳은 없다.
[25-7:8](/workspaces/filune/src/docs/source/25-7_rev16.md:8) 승인 항목(지시문 절)	적용	문서 A	문서 B	문서 D
[25-7:9](/workspaces/filune/src/docs/source/25-7_rev16.md:9) G-1 월령 격국·동일 오행 투출·정격/변격/겸격·투출 후 합거(2)	적용	A-8-1 I-01·I-02·I-02a·C-10, I-02 행·C-10 행 표시	W-98	Q16
[25-7:10](/workspaces/filune/src/docs/source/25-7_rev16.md:10) G-2·G-7 용신·상신·병·구응 10단계, 순용·역용, 합거 길흉, 병 제거 운(3)	적용	A-8-2 I-04-1·I-04-2·I-04a·I-04c, I-00 표시	W-90~W-92	Q6 표시·Q16
[25-7:11](/workspaces/filune/src/docs/source/25-7_rev16.md:11) G-3 조후 범위·강화/완화(4)	적용	A-8-3 I-04b	W-96	Q16
[25-7:12](/workspaces/filune/src/docs/source/25-7_rev16.md:12) G-8 지장간 체계	적용(IR-02로 2-2와 통합)	A-8-1 C-10·A-8-9 IR-02, U-A4 표시	W-98	Q15
[25-7:13](/workspaces/filune/src/docs/source/25-7_rev16.md:13) 천간합 OP-T09 개정·OP-T12·OP-T10 개정·OP-T11 개정·OP-T08 보완(5)	적용	A-8-4, OP-T01·T05·T09·T10 행·A-7 표시	W-80·W-81	Q4 표시·Q17
[25-7:14](/workspaces/filune/src/docs/source/25-7_rev16.md:14) 지지 동시 합·합충 동시·반복 육합·N-04·N-07(6)	적용	A-8-5 OP-Z10~Z13·Z07·Z09, OP-Z06·Z09 행 표시	W-82·W-85·W-94·W-95	Q18
[25-7:15](/workspaces/filune/src/docs/source/25-7_rev16.md:15) 운의 단계별 범위·상태 승계(7)	적용	A-8-6 OP-L01·L02, I-12 행 표시	W-81	Q17
[25-7:16](/workspaces/filune/src/docs/source/25-7_rev16.md:16) 천간·지지 독립 해석(8)	적용	A-8-7 OP-L03, I-14 행 표시	흐름 칸·W-93	Q19
[25-7:17](/workspaces/filune/src/docs/source/25-7_rev16.md:17) 실무 6그룹 U-A3·U-N5·U-N6·U-N7·U-N8·N-08·상태 승계·고객 문장(9)	적용	A-8-8 OP-P01~P05, A-3 해당 행 '운영 해결' 표시	W-97·W-99	Q15·Q19, G-1 상태표
[25-7:18](/workspaces/filune/src/docs/source/25-7_rev16.md:18) 학설 미확정과 운영 해결 구분(15)	적용	A-3 서문, A-8-8 끝 문단	—	G-1

## ② 개정 문서 목록

[25-7:19](/workspaces/filune/src/docs/source/25-7_rev16.md:19) ② 개정 문서 목록
[25-7:20](/workspaces/filune/src/docs/source/25-7_rev16.md:20) 문서	이전 rev	새 rev	수정 절
[25-7:21](/workspaces/filune/src/docs/source/25-7_rev16.md:21) A 명리 해석 기준서	46	72	A-0 OP 문단, I-00, I-02, I-12, I-14, C-10, A-3 서문·U-A3·U-A4·U-A5·U-N5~U-N8, OP-T01·T05·T09·T10, OP-Z06·Z09, A-5-5 U-O3, A-7 제목·A-7-1·A-7-2, 신설 A-8(A-8-1~A-8-9)
[25-7:22](/workspaces/filune/src/docs/source/25-7_rev16.md:22) B 고객용 감정서 작성 기준서	29	35	W-80·W-81·W-82·W-85, 흐름 칸, 신설 B-1-10(W-90~W-99)
[25-7:23](/workspaces/filune/src/docs/source/25-7_rev16.md:23) C 통합 검증 사례집	71	74	신설 C-10(회귀검증, 20항목·월별·원인·고객 문서). C-1~C-9는 그대로
[25-7:24](/workspaces/filune/src/docs/source/25-7_rev16.md:24) D 품질 검사·운영 단계·미확정 과제	65	67	Q4·Q6 표시, 신설 G(Q15~Q19)·G-1(미확정 상태 변경)
[25-7:25](/workspaces/filune/src/docs/source/25-7_rev16.md:25) ㉕ 1단계 독립 분석본	16	16	변경 없음(동결 유지)
[25-7:26](/workspaces/filune/src/docs/source/25-7_rev16.md:26) ㉕-7(이 문서)	—	신규	CS-127 회귀검증본 + 통합 보고
[25-7:27](/workspaces/filune/src/docs/source/25-7_rev16.md:27) 이전 rev는 각 문서의 판 기록에 남아 있어 그대로 불러올 수 있다. ㉕ 1단계가 참조한 문서 D는 작성 당시 rev 64였고(그 뒤 65), 이번 개정으로 67이 되었다.

## ⑩ 최종 완료 판정: 완료

[25-7:28](/workspaces/filune/src/docs/source/25-7_rev16.md:28) ⑩ 최종 완료 판정: 완료
[25-7:29](/workspaces/filune/src/docs/source/25-7_rev16.md:29) 완료 조건(지시문 17)	결과
[25-7:30](/workspaces/filune/src/docs/source/25-7_rev16.md:30) 1 승인 규칙 문서 A 반영	충족(A-8 + 해당 행 표시)
[25-7:31](/workspaces/filune/src/docs/source/25-7_rev16.md:31) 2 문서 B 고객 문장 일치	충족(W-80~W-86 수정, W-90~W-99 신설)
[25-7:32](/workspaces/filune/src/docs/source/25-7_rev16.md:32) 3 문서 C 회귀검증	충족(C-10)
[25-7:33](/workspaces/filune/src/docs/source/25-7_rev16.md:33) 4 문서 D 검사 항목	충족(Q15~Q19, Q4·Q6, G-1)
[25-7:34](/workspaces/filune/src/docs/source/25-7_rev16.md:34) 5 ㉕ 동결본 유지	충족(rev 16)
[25-7:35](/workspaces/filune/src/docs/source/25-7_rev16.md:35) 6 CS-127 신규 재해석 별도 작성	충족(이 문서 ⑤)
[25-7:36](/workspaces/filune/src/docs/source/25-7_rev16.md:36) 7 충돌 구문 식별·정리	충족. 표시 없이 남은 문장은 ⑧ 끝에 적음(A-0·A-7 제목의 A-8 우선 규정으로 판정 충돌은 없음)
[25-7:37](/workspaces/filune/src/docs/source/25-7_rev16.md:37) 8 G-1·G-2·G-3·G-7·G-8	충족
[25-7:38](/workspaces/filune/src/docs/source/25-7_rev16.md:38) 9 N-04·N-07 + 실무 6그룹	충족
[25-7:39](/workspaces/filune/src/docs/source/25-7_rev16.md:39) 10 운의 계층·상태 승계 일관 적용	충족(네 사례 월운에서 대운 직접 비교 제거)
[25-7:40](/workspaces/filune/src/docs/source/25-7_rev16.md:40) 11 구규칙 비교표	충족(③)
[25-7:41](/workspaces/filune/src/docs/source/25-7_rev16.md:41) 12 출처 상태 구분	충족(⑦)
[25-7:42](/workspaces/filune/src/docs/source/25-7_rev16.md:42) 제한: CS-005·CS-109의 대운·세운 축별 판정은 기존 근거를 새 규칙에 따라 천간·지지 축으로 다시 나눈 것이며, 과거 대운 전체를 다시 판정하지는 않았다(지시 대상은 현재·다음 대운과 12개월). 기존 고객 감정서는 동결본이므로 고치지 않았고, 재발송 시 수정할 위치만 C-10-1에 기록했다.

## ③ 구규칙 충돌 해결 표

[25-7:43](/workspaces/filune/src/docs/source/25-7_rev16.md:43) ③ 구규칙 충돌 해결 표
[25-7:44](/workspaces/filune/src/docs/source/25-7_rev16.md:44) 수정 위치는 모두 실제 문서에 반영한 곳이다. 이전 문장은 삭제하지 않고 '[2026-11-13 …] (이력)' 표시를 앞에 붙여 보존했다.
[25-7:45](/workspaces/filune/src/docs/source/25-7_rev16.md:45) #	구규칙·잠정안	이전 문장(요지)	새 기준	실제 수정 위치	관련 사례·회귀 결과	상태
[25-7:46](/workspaces/filune/src/docs/source/25-7_rev16.md:46) 1	월간–시간 합이불합 기본값	"원국 월간–시간의 천간합은 합이불합으로 처리한다"	원칙 합거	A OP-T09 행, OP-T01 조건 칸, A-8-4 / B W-80 / D Q4·Q17	CS-127 월간 壬–丁 합거. 원고 18개 중 합 작용으로 본 사례와 같은 방향	반영
[25-7:47](/workspaces/filune/src/docs/source/25-7_rev16.md:47) 2	일간·년간 극 개입 시 합이불합	㉕-5·6 'C 예외 검토, 두 가정 병기'	극 개입만으로 합거 취소 안 함	A-8-4 OP-T09 / D Q4 ⑧·G-1	CS-127 가정 ㄴ 폐기. 원고 044·065·071·087은 다른 판단이지만 기준 유지(지시 12)	반영
[25-7:48](/workspaces/filune/src/docs/source/25-7_rev16.md:48) 3	원국 다대일 불명확	G-4 보류, '미확정' 표시	가까운 유효 상대 합거, 나머지 유지	A-8-4 OP-T12 / B W-80 / D Q4 ⑨·G-1	CS-127 년간 壬 유지, CS-109 시간 癸 유지(결과 같음)	반영
[25-7:49](/workspaces/filune/src/docs/source/25-7_rev16.md:49) 4	운–원국 합 우선(U-O4 구안)	"원국과 이미 합거된 운 천간은 다른 운 천간과 다시 합하지 않는다"	운끼리 합 우선	A OP-T10 행·OP-T05 조건 칸, A-8-4 / B W-81 / D Q4 ⑦	CS-005 1월(상신 丙 유지), CS-126 2026 세운·11~1월(원국 辛 유지)·2월(상신 丁 유지)	반영
[25-7:50](/workspaces/filune/src/docs/source/25-7_rev16.md:50) 5	운끼리 합 후 원국 재합 가능성	지정 없음	중복 합 금지	A-8-4 OP-T10 ③ / D Q17	위 4와 같은 달	반영
[25-7:51](/workspaces/filune/src/docs/source/25-7_rev16.md:51) 6	운 다대일 합 처리	OP-T11 '대운→세운→월운'	대운 우선 + 직접 비교 범위만 + 일진 추가	A-8-4 OP-T11 / D Q4 ⑩	CS-109 2월: 월운은 대운과 비교하지 않아 상대가 세운 丁으로 바뀜	반영
[25-7:52](/workspaces/filune/src/docs/source/25-7_rev16.md:52) 7	여러 지지 합 중 하나만 우선	OP-Z06 "년지 → 월지 → 일지 → 시지 순서로 우선 적용"	모든 유효 합 동시, 순서는 표시용	A OP-Z06 행, A-8-5 OP-Z10 / B W-82 / D Q18	CS-109 2월 寅亥 육합 2회(월지·시지 亥)	반영
[25-7:53](/workspaces/filune/src/docs/source/25-7_rev16.md:53) 8	합이 충을 무조건 해소	I-09 고전 이론, W-85	충 존재 + 영향 크게 약화	A-8-5 OP-Z11 / B W-85·W-94 / D Q18	CS-109 巳亥 충 + 巳申 합, CS-127 丙午 대운 子午 충	반영
[25-7:54](/workspaces/filune/src/docs/source/25-7_rev16.md:54) 9	중복 육합 약한 강화·단순 중복 방지	OP-Z09 "먼저 성립한 합을 우선"	1·2·3회 이상 정성적 강화	A OP-Z09 행, A-8-5 / B W-82·W-95 / D Q18	CS-127 2026 세운 午未 2회, CS-109 8월 巳申 2회, CS-126 12월 子丑 2회	반영
[25-7:55](/workspaces/filune/src/docs/source/25-7_rev16.md:55) 10	합거 천간을 반합 투출 강화에 사용	N-04 미확정	사용 금지	A-8-5 OP-Z12 / D Q18	CS-126 5·9월(원국 辛 작용 중 → 강화), CS-127 8월(작용 중인 수 천간 없음 → 일반)	반영
[25-7:56](/workspaces/filune/src/docs/source/25-7_rev16.md:56) 11	묘고 충의 자동 개고	N-07 미확정	자동 개고 금지	A-8-5 OP-Z13 / D Q18	CS-127 4월 辰戌 충, CS-005 4·10월 辰戌	반영
[25-7:57](/workspaces/filune/src/docs/source/25-7_rev16.md:57) 12	천간·지지 상반 시 자동 혼합	I-14 '양쪽이 비등하면 혼합'	외부·내부 분리 설명	A I-14 행, A-8-7 OP-L03 / B 흐름 칸·W-93 / C C-10 / D Q19	네 사례 전 기간 축별 표기	반영
[25-7:58](/workspaces/filune/src/docs/source/25-7_rev16.md:58) 13	조후를 독립 용신·상신으로 사용	rev 16 '상신 丁(조후 겸 관)'	용신 기준 길흉의 강화·완화, 대상 한정	A-8-3 I-04b / B W-96 / D Q16	CS-127 상신 丁 → 酉. 세 사례는 대상 아님	반영
[25-7:59](/workspaces/filune/src/docs/source/25-7_rev16.md:59) 14	본기와 다른 음양을 투출에서 제외	㉕-5 G-8 '子의 壬은 투출 아님'	동일 오행이면 본기 투출	A I-02 행, C-10 행, A-8-1 / B W-98 / D Q16	CS-127 정격, CS-109 癸 본기 투출(비겁이라 격 아님)	반영
[25-7:60](/workspaces/filune/src/docs/source/25-7_rev16.md:60) 15	합거 후 투출 사실 삭제	지정 없음	분류 유지, 기능 정지	A-8-1 I-02a / B W-98 / D Q16	CS-127 월간 壬	반영
[25-7:61](/workspaces/filune/src/docs/source/25-7_rev16.md:61) 16	운의 모든 층위를 매번 직접 비교	I-12 "절기월 판정은 항상 세운·대운과 함께"	단계별 범위 + 상태 승계	A I-12 행, A-8-6 OP-L01·L02 / D Q17	CS-126 8·10월, CS-109 2·4~6월, CS-005 6·7월 근거 변경	반영
[25-7:62](/workspaces/filune/src/docs/source/25-7_rev16.md:62) 17	대운 해석을 월운에 동일 적용	U-A5·U-N6 잠정 운영	해당 운 단위에서 성패 재확인	A-3 U-A5·U-N6 행, A-8-6 OP-P03 / D Q19	CS-109 월운 대부분 S4 표시 유지	반영
[25-7:63](/workspaces/filune/src/docs/source/25-7_rev16.md:63) 통합 과정에서 나온 해석 정리(새 규칙 아님)는 A-8-9에 있다. 핵심은 IR-01(월운 단계는 세운–원국 관계를 다시 계산하지 않음)과 IR-02(지장간 목록은 기본 체계, 투출은 동일 오행)이다. 두 항목 모두 승인된 문구(7-2 '같은 합거를 다시 계산하지 않는다', 2-2)에서 도출한 정리이며, 새 판단 기준을 추가한 것이 아니다.

## ④ 회귀검증 결과 요약

[25-7:64](/workspaces/filune/src/docs/source/25-7_rev16.md:64) ④ 회귀검증 결과 요약
[25-7:65](/workspaces/filune/src/docs/source/25-7_rev16.md:65) 사례별 20항목과 월별 표는 문서 C C-10에, CS-127 전체는 이 문서 ⑤에 있다.
[25-7:66](/workspaces/filune/src/docs/source/25-7_rev16.md:66) 사례	기존 결과(동결본)	신규 결과(OP-1113)	주요 변경 원인
[25-7:67](/workspaces/filune/src/docs/source/25-7_rev16.md:67) CS-005 甲辰 丙寅 戊子 壬戌	칠살격, 상신 丙, 병 壬·子, 구응 戌. 1월 '혼합·부담 우세'(월운 辛이 상신 丙을 합거)	격·상신·병·구응 같음(겸격 분류 추가). 1월 천간 유리 우세(세운 丙–월운 辛 운끼리 합, 상신 유지)	OP-T10 개정, OP-L01(대운 未 월운 제외), OP-L03
[25-7:68](/workspaces/filune/src/docs/source/25-7_rev16.md:68) CS-109 戊申 癸亥 癸巳 癸亥	겁재월, 천간 戊 정관 용신 합거. 2월 '좋음 쪽(조건부)'	구조 같음(癸 본기 투출 인정, 비겁이라 격 아님). 2월 천간 영향 작음 / 지지 유리 우세	OP-L01(월운–대운 비교 제외), OP-Z10·Z07(寅亥 2회), OP-L03
[25-7:69](/workspaces/filune/src/docs/source/25-7_rev16.md:69) CS-126 辛未 戊戌 乙丑 丁丑	정재격, 상신 丁, 병 辛. 2026 세운 '유리'(세운 丙이 원국 辛 합거), 2월 '혼합'(월운 壬이 丁 합거)	2026 세운 천간 불리 우세(세운 丙은 대운 辛과 운끼리 합, 원국 辛 유지), 11월 천간 불리 우세, 2월 천간 유리 우세(상신 丁 유지), 8·10월 대운 寅 관계 제외	OP-T10 개정, OP-L01, OP-Z12, OP-L03
[25-7:70](/workspaces/filune/src/docs/source/25-7_rev16.md:70) CS-127 壬戌 壬子 辛未 丁酉	rev 16: 식상격(명칭 양립), 상신 丁, 병 壬·子, 구응 戌·未, 월간–시간 합이불합	식신격(정격), 천간 壬 상관 용신, 지지 상신 酉, 병 未·戌, 월간 壬–丁 합거, 년간 壬 유지. 대운 4개·세운 1개·12개월 전부 변경(방향 반대: 庚戌 대운, 2027 세운, 3·5·7·10월)	I-04b(조후로 상신 지정 금지), I-04-1·I-04-2, I-02 개정, OP-T09 개정, OP-L01·L03
[25-7:71](/workspaces/filune/src/docs/source/25-7_rev16.md:71) 판정 변화의 성격: 네 사례 모두 계산 오류로 바뀐 곳은 없으며, 각 변화는 위 원인 규칙 하나로 설명된다. 길흉 방향이 실제로 바뀐 곳은 CS-005 1월, CS-126 2026 세운·11·2월, CS-127 다수이다. CS-109는 방향이 바뀐 달이 없고 표기와 근거만 바뀌었다.
[25-7:72](/workspaces/filune/src/docs/source/25-7_rev16.md:72) 원고 월간–시간 합 18개 사례 대조: 새 OP-T09와 같은 방향 11개(합 작용), 다른 방향 4개(044·065·071·087, 합이불합·불완전), 판단 없음·불명 3개. 지시문 12에 따라 기준은 유지하고 차이만 기록했다(㉕-4·㉕-6 문서). 이 일치율은 전문가 판단 방법과의 재현성을 나타내며 적중 검증이 아니다.

## ⑤ CS-127 회귀검증본 (운영 규칙 개정 후 회귀검증)

[25-7:73](/workspaces/filune/src/docs/source/25-7_rev16.md:73) ⑤ CS-127 회귀검증본 (운영 규칙 개정 후 회귀검증)
[25-7:74](/workspaces/filune/src/docs/source/25-7_rev16.md:74) 성격: 블라인드 독립 검증이 아니다. 「사주풀이 예시」 전문가 원고(봉인 B, SHA-256 앞 16자리 3c5c8e177d6567c1 확인)를 이미 확인한 뒤 OP-1113 규칙을 적용한 회귀검증 결과이다. ㉕ 1단계 rev 16은 수정하지 않았고, ㉕-6의 시험 적용(가정 ㄱ·ㄴ)은 OP-T09 개정으로 가정 ㄱ만 남는다. 원고 판단에 맞추기 위해 규칙을 바꾼 곳은 없다.
[25-7:75](/workspaces/filune/src/docs/source/25-7_rev16.md:75) 명식: 壬戌 壬子 辛未 丁酉, 여성, 1982-12-14 酉시(계산값, ㉕-2 시주 검산). 대운 역행, 대운수 2년 4개월: 辛亥 → 庚戌 → 己酉 → 戊申 → 丁未(2025.4~2035.4) → 丙午.

## 5-1. 원국 판단 (지시문 12-2 항목별)

[25-7:76](/workspaces/filune/src/docs/source/25-7_rev16.md:76) 5-1. 원국 판단 (지시문 12-2 항목별)
[25-7:77](/workspaces/filune/src/docs/source/25-7_rev16.md:77) 확인 항목	결과	적용 규칙	출처 층
[25-7:78](/workspaces/filune/src/docs/source/25-7_rev16.md:78) 子월 본기 癸와 천간 壬	동일 오행(수) 본기 투출로 인정. 정격. 壬의 십신은 상관으로 구분(癸 식신과 다름)	I-02 개정	OP-1113
[25-7:79](/workspaces/filune/src/docs/source/25-7_rev16.md:79) 지지 식신격과 천간 壬의 역할	지지: 子 식신격(길신, 순용). 천간: 壬 상관 용신(흉신, 역용: 재를 생하거나 칠살을 다스리거나 인성에 제어될 때 쓸모)	I-04-1, A-8-2 ②	S2 + S3 + OP
[25-7:80](/workspaces/filune/src/docs/source/25-7_rev16.md:80) 원고의 천간 壬·지지 酉	壬 = 천간 용신(원고 용어 보존). 酉 = 지지 상신(食喜身旺: 일간을 받쳐 식신을 생하고 토→금→수로 인성을 통관)	I-03, I-04-1	S3(원고 직접) + S2
[25-7:81](/workspaces/filune/src/docs/source/25-7_rev16.md:81) 戌·未 인성의 실제 작용	未 편인(일지)·戌 정인(년지)이 子와 인접(戌–子, 子–未), 子未 해. 식신 손상 경로 있음 → 병. 단 酉가 통관해 식신은 기능 유지(원고 '식신이 살아나고 있음')	I-04-2	S2(梟神奪食) + S3
[25-7:82](/workspaces/filune/src/docs/source/25-7_rev16.md:82) 식신격에 대한 인성 손상	있음. 성패는 '병이 있으나 상신 酉가 버티는 성'. 棄食就煞而透印 형태는 천간에 인성이 없어 원국에서는 미충족	I-04-2	S2
[25-7:83](/workspaces/filune/src/docs/source/25-7_rev16.md:83) 월간 壬–시간 丁	합거. 극 개입(년간 壬이 丁을 극)만으로 합이불합으로 바꾸지 않음	OP-T09 개정	OP-1113
[25-7:84](/workspaces/filune/src/docs/source/25-7_rev16.md:84) 년간 壬–시간 丁, 다대일	丁의 상대는 壬 둘. 년간–시간은 OP-T02 합이불합이라 유효 경합이 아니고, 가까운 유효 상대는 월간 壬(OP-T12)	OP-T02·T12	OP
[25-7:85](/workspaces/filune/src/docs/source/25-7_rev16.md:85) 합거 후 남는 년간 壬	천간 壬은 월령에서 투출한 상관 용신이다. 월간 壬은 시간 丁과 합거되어 기능이 정지하지만, 년간 壬은 작용을 유지한다. 남은 년간 壬은 상관의 부정적인 작용으로 격국 성패에 부담을 줄 수 있으므로, 실제 제어·구응 관계를 검토하여 병의 역할을 판단한다. 월간 합거 때문에 년간까지 합거로 계산하지 않는다. 전문가 원고 근거(원고 '용신이지만 병이라고도')	OP-T12, I-02a	OP + S3
[25-7:86](/workspaces/filune/src/docs/source/25-7_rev16.md:86) 월간 壬의 투출 사실	유지(정격 분류 그대로). 기능만 정지	I-02a	OP-1113
[25-7:87](/workspaces/filune/src/docs/source/25-7_rev16.md:87) 합거의 길흉	壬(흉신 용신)과 丁(흉신 칠살)이 함께 멈춤 → 천간 흉한 작용이 제어돼 유리(원국 기본값). 원고 '칠살을 합해서 잡는 모양은 아주 좋음'과 같은 방향	I-04a	OP + S3
[25-7:88](/workspaces/filune/src/docs/source/25-7_rev16.md:88) 丁을 상신으로 본 rev 16 판단	타당하지 않음. 丁은 천간 축의 칠살(역용 대상)이고, 식신격(순용)의 상신은 酉	I-04-1, I-04b	—
[25-7:89](/workspaces/filune/src/docs/source/25-7_rev16.md:89) 조후를 상신 근거로 쓴 것	잘못 쓴 것이 맞음. rev 16은 丁을 '조후 겸 관'으로 상신 지정. 조후는 이 명식에 적용 대상(亥子丑월 辛)이지만 강화·완화에만 쓴다	I-04b	—

## 5-2. 대운 재판정 (대운 = 원국 + 대운)

[25-7:90](/workspaces/filune/src/docs/source/25-7_rev16.md:90) 5-2. 대운 재판정 (대운 = 원국 + 대운)
[25-7:91](/workspaces/filune/src/docs/source/25-7_rev16.md:91) 대운	rev 16	천간	지지	조후	원고
[25-7:92](/workspaces/filune/src/docs/source/25-7_rev16.md:92) 辛亥 (2~12)	부담 쪽	불리: 辛 비견이 남은 壬 상관을 키움	불리: 亥 상관(식신격에 상관). 亥未 반합(목 = 구응 기운)이 일부 완화	불충족	'상관이 들어오면 패', '비겁이 들어오면 상관이 커짐' — 일치
[25-7:93](/workspaces/filune/src/docs/source/25-7_rev16.md:93) 庚戌 (12~22)	좋음 쪽	불리: 庚이 壬을 생해 상관 강화	불리: 戌 정인 추가(병), 戌未 형·파, 戌酉 해(상신)	불충족	'식신격에 정인이 들어와 마음 편한 일 없고, 겁재로 상관이 커짐' — 일치(rev 16과는 반대)
[25-7:94](/workspaces/filune/src/docs/source/25-7_rev16.md:94) 己酉 (22~32)	혼합	유리: 己 인성이 남은 壬 상관을 제복	유리: 酉 상신 강화(酉酉 자형·子酉 파 동반)	—	'기토가 상관을 극해 쓸 수 있고, 비견이 들어오면 식신이 살아남' — 일치
[25-7:95](/workspaces/filune/src/docs/source/25-7_rev16.md:95) 戊申 (32~42)	혼합	유리: 戊 인성이 壬 제복	유리: 申酉戌 방합(금 계절 강화, 상신 강화). 申子 반합은 작용 중인 년간 壬이 있어 투출 강화 반합(식신 강화, OP-Z12)	—	'무신대운까지 가능' — 일치
[25-7:96](/workspaces/filune/src/docs/source/25-7_rev16.md:96) 丁未 (42~52, 현재)	좋음 쪽	유리: 대운 丁→년간 壬 합거(OP-T07). 남은 병 壬과 칠살 丁이 함께 멈춤(I-04a). 천간에 작용하는 글자는 일간뿐	불리: 未 편인 추가 = 편인도식 강화, 子未 해. 酉가 남아 버틸	충족 쪽(未) → 지지 부담 완화	'천간 칠살이 잡히는 모습은 굉장히 좋음, 내부적으로는 식신이 깨짐, 비견이 있어 넘어갈 수는' — 일치
[25-7:97](/workspaces/filune/src/docs/source/25-7_rev16.md:97) 丙午 (52~62)	혼합	불리: 남은 년간 壬이 丙 정관을 극(상관견관). 丙의 합 상대는 일간뿐이라 제외(OP-T04). 원국 丁은 합거 상태라 관살혼잡 없음	유리: 子午 충(식신이 칠살을 다룸)은 午未 육합·午戌 반합이 함께 있어 영향이 약해짐. 대신 午未 육합·午戌 반합에 병(未·戌)이 참여해 작용이 약해짐(지지합은 합거가 아님, OP-Z10)	충족 → 지지 유리 강화	'천간은 패, 지지는 대승 + 조후' — 방향 일치

| 기대값 행 | 해당 행 직접 Rule ID | 출처 |
| --- | --- | --- |
| 辛亥 (2~12) | 문서상 직접 참조 없음 | [25-7:92](/workspaces/filune/src/docs/source/25-7_rev16.md:92) |
| 庚戌 (12~22) | 문서상 직접 참조 없음 | [25-7:93](/workspaces/filune/src/docs/source/25-7_rev16.md:93) |
| 己酉 (22~32) | 문서상 직접 참조 없음 | [25-7:94](/workspaces/filune/src/docs/source/25-7_rev16.md:94) |
| 戊申 (32~42) | OP-Z12 | [25-7:95](/workspaces/filune/src/docs/source/25-7_rev16.md:95) |
| 丁未 (42~52, 현재) | I-04a, OP-T07 | [25-7:96](/workspaces/filune/src/docs/source/25-7_rev16.md:96) |
| 丙午 (52~62) | OP-T04, OP-Z10 | [25-7:97](/workspaces/filune/src/docs/source/25-7_rev16.md:97) |

## 5-3. 세운 (세운 = 원국 + 대운 + 세운)

[25-7:98](/workspaces/filune/src/docs/source/25-7_rev16.md:98) 5-3. 세운 (세운 = 원국 + 대운 + 세운)
[25-7:99](/workspaces/filune/src/docs/source/25-7_rev16.md:99) 바탕 상태: 원국 월간 壬·시간 丁 합거, 대운 丁–년간 壬 합거(대운 단계의 원국 변화). 원국 천간 중 작용하는 글자는 일간 辛뿐.
[25-7:100](/workspaces/filune/src/docs/source/25-7_rev16.md:100) 세운	rev 16	천간	지지	조후
[25-7:101](/workspaces/filune/src/docs/source/25-7_rev16.md:101) 2026 丙午	좋음 쪽(관 부담 동반)	유리: 운끼리 丙–丁 합 없음, 丙의 원국 상대는 일간뿐. 정관 丙이 상관·칠살의 간섭 없이 드러남	유리: 午未 육합 2회(일지 未 + 대운 未, 강한 육합)로 병 未이 크게 약해짐. 午戌 반합(丙 투출 강화). 子午 충은 합 개입으로 약화	충족 → 강화
[25-7:102](/workspaces/filune/src/docs/source/25-7_rev16.md:102) 2027 丁未	좋음 쪽(인성 과다 부담 동반)	불리: 세운 丁의 합 상대(壬)는 모두 합거 상태 → 칠살 丁이 제어 없이 작용	불리: 未 세 겹(일지·대운·세운) 편인도식, 子未 해 반복, 戌未 형	충족 쪽 → 지지 부담 완화

| 기대값 행 | 해당 행 직접 Rule ID | 출처 |
| --- | --- | --- |
| 2026 丙午 | 문서상 직접 참조 없음 | [25-7:101](/workspaces/filune/src/docs/source/25-7_rev16.md:101) |
| 2027 丁未 | 문서상 직접 참조 없음 | [25-7:102](/workspaces/filune/src/docs/source/25-7_rev16.md:102) |

## 5-4. 월운 (월운 = 원국 + 세운 + 월운, 대운은 원국 변화만 승계)

[25-7:103](/workspaces/filune/src/docs/source/25-7_rev16.md:103) 5-4. 월운 (월운 = 원국 + 세운 + 월운, 대운은 원국 변화만 승계)
[25-7:104](/workspaces/filune/src/docs/source/25-7_rev16.md:104) 승계 상태: 년간 壬은 대운 丁과 합거(유효기간 2035.4까지). 대운 未은 월운 관계표에 넣지 않음(OP-L01).
[25-7:105](/workspaces/filune/src/docs/source/25-7_rev16.md:105) 달	간지	rev 16	천간	지지	핵심 근거
[25-7:106](/workspaces/filune/src/docs/source/25-7_rev16.md:106) 2026.11	己亥	혼합	유리	공존	丙→己→辛 관인상생 / 亥 상관 vs 午未 육합·亥未 반합으로 병 未 약화
[25-7:107](/workspaces/filune/src/docs/source/25-7_rev16.md:107) 12	庚子	부담	영향 작음	불리	丙이 庚을 다스림 / 子 겹침·子酉 파(상신)·한랭(조후 악화)
[25-7:108](/workspaces/filune/src/docs/source/25-7_rev16.md:108) 2027.1	辛丑	부담 쪽	영향 작음	불리 우세	丙辛 운끼리 합(둘 다 약화) / 子丑 육합(격 子 약화)·丑 편인 추가·丑戌未 삼형, 酉丑 반합은 상신 강화
[25-7:109](/workspaces/filune/src/docs/source/25-7_rev16.md:109) 2	壬寅	혼합	유리 우세	공존	세운 丁–월운 壬 운끼리 합 → 칠살 약화 / 寅 재(구응)·寅戌 반합 vs 세운 未 편인
[25-7:110](/workspaces/filune/src/docs/source/25-7_rev16.md:110) 3	癸卯	부담	유리	유리 우세	癸 식신이 丁 칠살을 극 = 식신제살 / 卯 재(구응)·卯戌 육합·卯未 반합으로 병 약화, 卯酉 충·子卯 형은 합 개입으로 약화
[25-7:111](/workspaces/filune/src/docs/source/25-7_rev16.md:111) 4	甲辰	혼합	불리	불리 우세	甲 재가 丁을 생(재생살) / 辰 인성 추가·辰酉 육합(상신 약화), 辰戌 충은 개고 없음(OP-Z13)
[25-7:112](/workspaces/filune/src/docs/source/25-7_rev16.md:112) 5	乙巳	좋음	불리	유리 우세	乙 재가 丁을 생 / 巳酉 반합(상신 강화)·조후 충족 vs 巳 정관 손상
[25-7:113](/workspaces/filune/src/docs/source/25-7_rev16.md:113) 6	丙午	좋음 쪽	불리	유리	丙丁 관살혼잡 무제어 / 午未 육합 2회(원국·세운 未)으로 병 약화, 午戌 강화 반합, 조후 충족
[25-7:114](/workspaces/filune/src/docs/source/25-7_rev16.md:114) 7	丁未	좋음 쪽	불리	불리 우세	칠살 둘 무제어 / 未 세 겹 편인도식(조후로 완화)
[25-7:115](/workspaces/filune/src/docs/source/25-7_rev16.md:115) 8	戊申	좋음 쪽	유리	유리	丁→戊→辛 살인상생(인성이 하늘에 뜨는 棄食就煞而透印 형태) / 申酉戌 방합·申子 반합(작용 중인 수 천간 없음 → 일반 반합)
[25-7:116](/workspaces/filune/src/docs/source/25-7_rev16.md:116) 9	己酉	혼합	유리	유리 우세	丁→己→辛 살인상생 / 酉 상신 강화(酉酉 자형·子酉 파·戌酉 해 동반)
[25-7:117](/workspaces/filune/src/docs/source/25-7_rev16.md:117) 10	庚戌	좋음 쪽	불리 우세	불리 우세	칠살 무제어 지속(庚이 일간을 조금 받침) / 戌 인성 추가·戌酉 해
[25-7:118](/workspaces/filune/src/docs/source/25-7_rev16.md:118) 구규칙과 달라진 핵심: rev 16은 丁을 상신으로 보아 '丁을 돕는 달 = 좋음, 丁을 극하는 달 = 부담'으로 판정했다. 새 기준에서 丁은 제어해야 할 칠살(편관)이고 상신은 酉, 병은 未·戌이므로 판정 방향이 반대로 바뀐 달이 많다(3·5·7·10월, 2027 세운, 庚戌 대운). 이는 규칙 변경에 따른 정상 변화이며 계산 오류가 아니다.

| 기대값 행 | 해당 행 직접 Rule ID | 출처 |
| --- | --- | --- |
| 2026.11 | 문서상 직접 참조 없음 | [25-7:106](/workspaces/filune/src/docs/source/25-7_rev16.md:106) |
| 12 | 문서상 직접 참조 없음 | [25-7:107](/workspaces/filune/src/docs/source/25-7_rev16.md:107) |
| 2027.1 | 문서상 직접 참조 없음 | [25-7:108](/workspaces/filune/src/docs/source/25-7_rev16.md:108) |
| 2 | 문서상 직접 참조 없음 | [25-7:109](/workspaces/filune/src/docs/source/25-7_rev16.md:109) |
| 3 | 문서상 직접 참조 없음 | [25-7:110](/workspaces/filune/src/docs/source/25-7_rev16.md:110) |
| 4 | OP-Z13 | [25-7:111](/workspaces/filune/src/docs/source/25-7_rev16.md:111) |
| 5 | 문서상 직접 참조 없음 | [25-7:112](/workspaces/filune/src/docs/source/25-7_rev16.md:112) |
| 6 | 문서상 직접 참조 없음 | [25-7:113](/workspaces/filune/src/docs/source/25-7_rev16.md:113) |
| 7 | 문서상 직접 참조 없음 | [25-7:114](/workspaces/filune/src/docs/source/25-7_rev16.md:114) |
| 8 | 문서상 직접 참조 없음 | [25-7:115](/workspaces/filune/src/docs/source/25-7_rev16.md:115) |
| 9 | 문서상 직접 참조 없음 | [25-7:116](/workspaces/filune/src/docs/source/25-7_rev16.md:116) |
| 10 | 문서상 직접 참조 없음 | [25-7:117](/workspaces/filune/src/docs/source/25-7_rev16.md:117) |

## ⑥ 계산 검증

[25-7:119](/workspaces/filune/src/docs/source/25-7_rev16.md:119) ⑥ 계산 검증
[25-7:120](/workspaces/filune/src/docs/source/25-7_rev16.md:120) 사례	역법·시주 경계	직접 계산	불확실성
[25-7:121](/workspaces/filune/src/docs/source/25-7_rev16.md:121) CS-005	입춘 뒤 寅월, 戌시(C-03 19:30~21:29)	기존 확정값 유지(lunar_python + PyEphem 대조, C-1 ②)	출생연도는 역산값(1904/1964 중 원고 문맥으로 1964)
[25-7:122](/workspaces/filune/src/docs/source/25-7_rev16.md:122) CS-109	입동 1968-11-07 17:29 / 17:19(두 도구 10분 차), 亥시	대운수 4년 0.7~1.0개월, 丁巳 2022-12 중순	원고 연도 기반으로 사실상 확정
[25-7:123](/workspaces/filune/src/docs/source/25-7_rev16.md:123) CS-126	입동 1991-11-08 07:07 / 07:05, 丑시	대운수 5년 8.6~8.9개월, 壬寅 교운 2027-07 중순	출생연도 역산값(1931/1991 중 1991)
[25-7:124](/workspaces/filune/src/docs/source/25-7_rev16.md:124) CS-127	1982-12-14 酉시. 도구 기본값(17:00~18:59)과 C-03(17:30~19:29)이 다름. ㉕-2에서 4칸 검산(문서 D E-5)	대운수 2년 4개월(두 계산 일치)	㉕ 1단계의 '17:00~19:20 모두 丁酉' 기록 오류는 ㉕-2에서 정정, 결과 丁酉는 그대로
[25-7:125](/workspaces/filune/src/docs/source/25-7_rev16.md:125) 이번 개정으로 바뀐 계산값은 없다. 절기월(2026.11~2027.10)과 세운 경계(2027-02-04)는 네 사례 공통 확정값이다.

## ⑦ 출처 구분

[25-7:126](/workspaces/filune/src/docs/source/25-7_rev16.md:126) ⑦ 출처 구분
[25-7:127](/workspaces/filune/src/docs/source/25-7_rev16.md:127) 표시	이번에 쓴 곳
[25-7:128](/workspaces/filune/src/docs/source/25-7_rev16.md:128) S1 계산	원국·대운·절기·시주 경계(⑥)
[25-7:129](/workspaces/filune/src/docs/source/25-7_rev16.md:129) S2 원전	八字用神專求月令, 善而順用/不善而逆用, 梟神奪食宜用財制, 食帶煞而無財棄食就煞而透印, 相神有傷立敗其格(A-8-1·A-8-2 근거 대조 칸)
[25-7:130](/workspaces/filune/src/docs/source/25-7_rev16.md:130) S3 원고	CS-127 지지 상신 酉·병 未戌·월간 壬의 丁 합·대운 판단, 세 사례의 대운 판단, 정격·변격·겸격 설명(P129~P131)
[25-7:131](/workspaces/filune/src/docs/source/25-7_rev16.md:131) S4 확장	원고 대운 판단을 세운·월운에 옮긴 모든 칸(CS-109 월운 대부분, CS-127 세운·월운 전부)
[25-7:132](/workspaces/filune/src/docs/source/25-7_rev16.md:132) S5 학설 미확정	합충 해소 학설 차이, 천간충 독자 작용, 천간 극 거리의 고전 범위, 학파별 지장간·시주 경계
[25-7:133](/workspaces/filune/src/docs/source/25-7_rev16.md:133) OP-1113	A-8 전부. 판정은 이것을 따르고 원전·원고 법칙으로 표기하지 않음

## ⑧ 문서 간 일관성 검사

[25-7:134](/workspaces/filune/src/docs/source/25-7_rev16.md:134) ⑧ 문서 간 일관성 검사
[25-7:135](/workspaces/filune/src/docs/source/25-7_rev16.md:135) 판단(A)	표현(B)	사례(C)	검사(D)	연결
[25-7:136](/workspaces/filune/src/docs/source/25-7_rev16.md:136) OP-T09 개정 월간–시간 합거	W-80	C-10 CS-127	Q4 ⑧·Q17	연결됨
[25-7:137](/workspaces/filune/src/docs/source/25-7_rev16.md:137) OP-T10·T11 운끼리 합 우선·대운 우선	W-81	C-10 CS-005 1월·CS-126 2026 세운	Q4 ⑦⑩·Q17	연결됨
[25-7:138](/workspaces/filune/src/docs/source/25-7_rev16.md:138) OP-T12 원국 다대일	W-80	C-10 CS-127·CS-109	Q4 ⑨	연결됨
[25-7:139](/workspaces/filune/src/docs/source/25-7_rev16.md:139) OP-Z10·Z11·Z07·Z09	W-82·W-85·W-94·W-95	C-10 CS-109 2·8월	Q18	연결됨
[25-7:140](/workspaces/filune/src/docs/source/25-7_rev16.md:140) OP-Z12·Z13	(표현 규칙 불필요: 내부 강도)	C-10 CS-126 5·9월	Q18	연결됨
[25-7:141](/workspaces/filune/src/docs/source/25-7_rev16.md:141) OP-L01·L02	W-81	C-10 C-10-3	Q17	연결됨
[25-7:142](/workspaces/filune/src/docs/source/25-7_rev16.md:142) OP-L03 축별 판정	흐름 칸·W-93	C-10 전체 표기	Q19	연결됨
[25-7:143](/workspaces/filune/src/docs/source/25-7_rev16.md:143) I-02·I-02a 투출	W-98	C-10 20항목 4·5	Q16	연결됨
[25-7:144](/workspaces/filune/src/docs/source/25-7_rev16.md:144) I-04-1·I-04-2·I-04a·I-04c	W-90~W-92	CS-127 ⑤	Q16	연결됨
[25-7:145](/workspaces/filune/src/docs/source/25-7_rev16.md:145) I-04b 조후	W-96	C-10 15항목	Q16	연결됨
[25-7:146](/workspaces/filune/src/docs/source/25-7_rev16.md:146) OP-P02·P04 계산·역산	W-97	C-10 1항목	Q15	연결됨
[25-7:147](/workspaces/filune/src/docs/source/25-7_rev16.md:147) OP-P05 고객 문장	W-99	C-10-4	Q19	연결됨
[25-7:148](/workspaces/filune/src/docs/source/25-7_rev16.md:148) 남은 불일치: 2026-11-13 통합 당시 월간–시간 합이불합 문구가 남아 있던 A-5-1·A-5-5·A-7-1·A-7-2의 네 곳에 '[2026-11-13 개정] (이력)' 표시를 넣었다. 그때 표시 없이 남았던 I-08 조건 칸의 'OP-T01~T08로만', A-7-2의 구 OP-T10·T11 설명 등은 2026-11-15 정리에서 A-8 참조와 '(이력)' 표시를 붙였다(아래 '추가 정리' 표).

## ⑨ 남은 사항

[25-7:149](/workspaces/filune/src/docs/source/25-7_rev16.md:149) ⑨ 남은 사항
[25-7:150](/workspaces/filune/src/docs/source/25-7_rev16.md:150) 운영 기준 미확정(서비스 판정에 영향): 없음. 이번 승인 항목을 다시 미확정으로 올리지 않았다.
[25-7:151](/workspaces/filune/src/docs/source/25-7_rev16.md:151) 학설상 연구 과제(연구 이력으로만 보존):
[25-7:152](/workspaces/filune/src/docs/source/25-7_rev16.md:152) 1.	합이 충을 푸는 원전 조항과 충이 합을 깨는다는 해설의 차이
[25-7:153](/workspaces/filune/src/docs/source/25-7_rev16.md:153) 2.	천간충의 생극과 구별되는 독자 작용(U-N4)
[25-7:154](/workspaces/filune/src/docs/source/25-7_rev16.md:154) 3.	원국 천간 극의 거리에 대한 고전의 적용 범위
[25-7:155](/workspaces/filune/src/docs/source/25-7_rev16.md:155) 4.	학파별 지장간·시주 경계 차이
[25-7:156](/workspaces/filune/src/docs/source/25-7_rev16.md:156) 5.	운 단위별 원고 직접 판단이 부족한 영역(특히 월운)
[25-7:157](/workspaces/filune/src/docs/source/25-7_rev16.md:157) 6.	과거 명식 출생연도 역산의 불확실성(CS-005·CS-126)
[25-7:158](/workspaces/filune/src/docs/source/25-7_rev16.md:158) 7.	원고의 월간–시간 합이불합 4건(044·065·071·087)이 보여주는 전문가 기준(운영 기준은 OP-T09로 확정)
[25-7:159](/workspaces/filune/src/docs/source/25-7_rev16.md:159) 운영 과제(규칙이 아닌 작업): ① 신규 명식 엔진 테스트(규칙 적용 일관성·계산 정확성·예외 처리·고객 문장 품질), 설계는 문서 D H절 ② 기존 고객 감정서 재발송 시 C-10-1 20번 항목 반영 ③ A-5·A-7·A-2 본문의 이전 문장 정리(2026-11-15 완료).
[25-7:160](/workspaces/filune/src/docs/source/25-7_rev16.md:160) [2026-11-15 운영자 지시] 「사주풀이 예시」는 외부 전문가의 실제 사주풀이 원고(약 130개 이상 명식)이며, FILUNE의 핵심 연구·검증 자료로 이미 활용했다. 명리 해석 운영 기준은 이 원고와 고전·연구자료로 확정되었다. 향후 검증에는 원고 가운데 개별 검증에 쓰지 않은 사례를 활용할 수 있으나, 원고 전체를 이미 분석했으므로 완전히 독립적인 블라인드 검증으로 부르지 않는다. 새로운 외부 전문가 자료는 서비스 개발과 해석 엔진 완성의 선행 조건이 아니며, 실제 예측 적중도 검증은 별도의 선택 평가 활동으로만 기록한다(문서 D H-4).
[25-7:161](/workspaces/filune/src/docs/source/25-7_rev16.md:161) 추가 정리 (2026-11-15)
[25-7:162](/workspaces/filune/src/docs/source/25-7_rev16.md:162) 작업	결과	위치
[25-7:163](/workspaces/filune/src/docs/source/25-7_rev16.md:163) 새 외부 전문가 자료를 필수 과제·선행 조건에서 제외	제외. 「사주풀이 예시」(외부 전문가 원고)는 이미 핵심 연구·검증 자료로 활용함. 원고 미사용 사례 대조와 예측 적중도 검증은 선택 평가 활동으로만 기록	이 문서 ⑨, A A-8-10, D G-1·H-4
[25-7:164](/workspaces/filune/src/docs/source/25-7_rev16.md:164) 문서 A 구규칙 문장 정리	I-08 두 칸, I-09, I-14 판정 표기, C-11, A-0 OP 문단, A-4-4 서문, OP-T11·OP-Z06 예외·OP-Z09 대조 칸, A-5-5 U-O4·U-O5·U-O6, A-6-6 표, A-7 서문·A-7-1 두 항목·A-7-2 세 행에 A-8 참조와 '(이력)' 표시	A rev 72 → 95
[25-7:165](/workspaces/filune/src/docs/source/25-7_rev16.md:165) 문서 B 정리	흐름 칸의 '승인 전 확장 제안 U-O7·U-O8 → ~하면' 문장 정리, W-86 운끼리 합 우선 표시	B rev 35 → 38
[25-7:166](/workspaces/filune/src/docs/source/25-7_rev16.md:166) 문서 C 정리	C-0 최신본 안내에 '현행 판정은 C-10' 표시	C rev 74 → 75
[25-7:167](/workspaces/filune/src/docs/source/25-7_rev16.md:167) 문서 D 정리·설계	Q5 비교 범위·육합 기준 개정 표시, G-1 상태 변경, H절 해석 엔진 테스트 설계(NT-01~09 신규 명식, CT-01~07 계산, RT-01~13 규칙, ST-01~07 문장, 합격 기준)	D rev 67 → 75
[25-7:168](/workspaces/filune/src/docs/source/25-7_rev16.md:168) A·B·C·D 참조 일치	네 문서 모두 A-8의 같은 규칙 ID를 참조	⑧ 표 + A-8-10
[25-7:169](/workspaces/filune/src/docs/source/25-7_rev16.md:169) 동결본	㉕ 1단계 rev 16, 문서 C C-1~C-9, 기존 고객 감정서 그대로	—
[25-7:170](/workspaces/filune/src/docs/source/25-7_rev16.md:170) 엔진 구현 관련 확인 사항: OP-L01 범위에서는 한 판단 단계에 운 천간이 둘뿐이므로 운 다대일(OP-T11)은 교운기에 두 대운을 병기하는 경우(I-13)에만 발생한다. 새 기준을 만들지 않고, 기존 I-13 병기 방식으로 출력하는 것을 테스트 기대값(RT-13)으로 둔다.
[25-7:171](/workspaces/filune/src/docs/source/25-7_rev16.md:171) 문체·용어 정리와 최종 점검 (2026-11-15, 2차)
[25-7:172](/workspaces/filune/src/docs/source/25-7_rev16.md:172) 대상은 문서 A rev 95, B rev 38, C rev 75, D rev 75와 이 보고서이다. 신규 연구와 운영 규칙 변경은 하지 않았고, 명리 판단·승인 규칙·길흉 판정은 바뀌지 않았다. 문서 B는 고객 문장 기준서이므로 문체 변경 대상에서 제외하고 규칙 ID 일치만 점검했다. 이전 연구보고서(①~㉕-6)와 ㉕ 1단계 rev 16은 기록으로 두고 수정하지 않았다.
[25-7:173](/workspaces/filune/src/docs/source/25-7_rev16.md:173) 작업	결과	판 번호
[25-7:174](/workspaces/filune/src/docs/source/25-7_rev16.md:174) 문어체 통일	A·C·D의 구어체 종결(~해요·~예요·~했어요 등)을 '~한다·~이다'로 바꿈. 고객 문장 인용(LUNE 반말)은 원문 그대로 둠	A 95 → 176, C 75 → 175, D 75 → 149
[25-7:175](/workspaces/filune/src/docs/source/25-7_rev16.md:175) 모호한 표현 교체	C의 '하늘에 남음', '자유로워서', '묶여' 등을 '천간에서 작용을 유지', '합 상대 없이 독립 작용', '합거됨'으로 교체(17곳). ⑧ 이력의 인용문은 기록이므로 유지	C
[25-7:176](/workspaces/filune/src/docs/source/25-7_rev16.md:176) 전문가 자료 설명 정정	「사주풀이 예시」는 외부 전문가의 실제 원고(약 130개 이상 명식)이며 이미 핵심 자료로 활용했다는 사실을 명시. 향후 검증은 '원고 미사용 사례 대조'로 부르고 블라인드 검증이라 하지 않음. 새 외부 자료는 선행 조건이 아님	A A-8-10, C C-4, D G-1·T11·H-1·H-4, 이 문서
[25-7:177](/workspaces/filune/src/docs/source/25-7_rev16.md:177) 용어 통일	C-10의 '공존'이 A-8-7 '유불리 공존'의 줄임 표기임을 명시	C
[25-7:178](/workspaces/filune/src/docs/source/25-7_rev16.md:178) 지지 관계 기대값	NT-01~09의 십신과 원국 지지 관계(위치·인접/격위 포함)를 표로 신설	D H-3-1
[25-7:179](/workspaces/filune/src/docs/source/25-7_rev16.md:179) 점검에서 발견한 오류와 수정(근거가 기존 규칙·계산에 있는 항목만 반영했다):
[25-7:180](/workspaces/filune/src/docs/source/25-7_rev16.md:180) #	위치	오류	근거	수정
[25-7:181](/workspaces/filune/src/docs/source/25-7_rev16.md:181) 1	D H-3 NT-02	'戌 중기 辛'	戌 지장간은 여기 辛·중기 丁·본기 戊(C-10 기본 체계)	'戌 여기 辛'
[25-7:182](/workspaces/filune/src/docs/source/25-7_rev16.md:182) 2	D H-3 NT-03	壬 일간·子월을 본기 투출 정격으로 기대	子는 壬의 양인(겁재)월. A-8-1 I-01 조건 칸의 비겁월 특수 규정 대상	비겁월 특수 규정 적용, 월간 壬(비견)은 격으로 세우지 않음
[25-7:183](/workspaces/filune/src/docs/source/25-7_rev16.md:183) 3	D H-3 NT-09	상관격에 I-04-2 '준용'	I-04-2는 식신격 인성 규정	I-04-1 역용 기준으로 교체
[25-7:184](/workspaces/filune/src/docs/source/25-7_rev16.md:184) 4	C C-10-1 CS-127 병	'未·戌 인성(편인도식)'	辛 일간에서 戌은 정인	'未(편인)·戌(정인)이 식신 子를 극함(도식)'. 판정 불변
[25-7:185](/workspaces/filune/src/docs/source/25-7_rev16.md:185) 5	이 문서 5-2 丙午 대운	'병이 묶여'	지지합은 합거가 아님(OP-Z01·Z10)	'합에 참여해 작용이 약해짐'
[25-7:186](/workspaces/filune/src/docs/source/25-7_rev16.md:186) 6	C C-5-2	'하늘에서는 솔씨가 묶임'	'솔씨'는 '상신'의 오기(壬寅 대운 壬–丁 합거)	'천간에서는 상신이 합거됨'
[25-7:187](/workspaces/filune/src/docs/source/25-7_rev16.md:187) 운영자 결정 반영(2026-11-15). 이 세 항목을 끝으로 문체 수정과 규칙 재연구는 종료한다:
[25-7:188](/workspaces/filune/src/docs/source/25-7_rev16.md:188) #	결정	반영 위치
[25-7:189](/workspaces/filune/src/docs/source/25-7_rev16.md:189) P1	판정 표기 '유리 쪽 / 불리 쪽' → '유리 우세 / 불리 우세'. 강도 단계는 그대로. 이력 인용문은 변경하지 않음	A A-8-7, C C-10, 이 문서 ④·⑤
[25-7:190](/workspaces/filune/src/docs/source/25-7_rev16.md:190) P2	기존 G-1 승인 내용 적용: 비견·겁재는 천간 용신 선정과 겸격의 독립 용신에서 제외, 존재 사실과 생극·통근은 판단, 비겁월 특수 규정 유지	A A-8-1 I-02 조건 칸, D H-3 NT-06·NT-08·H-3-1
[25-7:191](/workspaces/filune/src/docs/source/25-7_rev16.md:191) P3	CS-127 천간 壬: 용신 壬과 병으로 작용하는 년간 壬을 구분하는 운영자 문구로 기술. 원고 '용신이지만 병이라고도' 근거 보존. 구응 칸의 '재(목) 원국에 없음'은 未 지장간 乙의 존재와 실제 기능을 구분해 정정	C C-10-1 7·8·9행, 이 문서 ⑤-1
[25-7:192](/workspaces/filune/src/docs/source/25-7_rev16.md:192) 일치 확인: 네 문서의 규칙 ID(OP-T01~T12, OP-Z01~Z13, OP-L01~L03, OP-P01~P05, OP-R01~R03, I-02a·I-04a·I-04b·I-04c)는 모두 A-8 또는 A-5 본문에 정의가 있고, 정의 없는 ID를 참조한 곳은 없다. 반합 범위(왕지 없는 짝도 일반 반합, OP-Z03)와 방합(세 지지, OP-Z04)은 C-10의 CS-109 '亥未 반합'과 D H-3-1에 같은 기준으로 적용되어 있다.

## 후기 운영자 결정 원문

[25-7:187](/workspaces/filune/src/docs/source/25-7_rev16.md:187) 운영자 결정 반영(2026-11-15). 이 세 항목을 끝으로 문체 수정과 규칙 재연구는 종료한다:
[25-7:188](/workspaces/filune/src/docs/source/25-7_rev16.md:188) #	결정	반영 위치
[25-7:189](/workspaces/filune/src/docs/source/25-7_rev16.md:189) P1	판정 표기 '유리 쪽 / 불리 쪽' → '유리 우세 / 불리 우세'. 강도 단계는 그대로. 이력 인용문은 변경하지 않음	A A-8-7, C C-10, 이 문서 ④·⑤
[25-7:190](/workspaces/filune/src/docs/source/25-7_rev16.md:190) P2	기존 G-1 승인 내용 적용: 비견·겁재는 천간 용신 선정과 겸격의 독립 용신에서 제외, 존재 사실과 생극·통근은 판단, 비겁월 특수 규정 유지	A A-8-1 I-02 조건 칸, D H-3 NT-06·NT-08·H-3-1
[25-7:191](/workspaces/filune/src/docs/source/25-7_rev16.md:191) P3	CS-127 천간 壬: 용신 壬과 병으로 작용하는 년간 壬을 구분하는 운영자 문구로 기술. 원고 '용신이지만 병이라고도' 근거 보존. 구응 칸의 '재(목) 원국에 없음'은 未 지장간 乙의 존재와 실제 기능을 구분해 정정	C C-10-1 7·8·9행, 이 문서 ⑤-1
[25-7:192](/workspaces/filune/src/docs/source/25-7_rev16.md:192) 일치 확인: 네 문서의 규칙 ID(OP-T01~T12, OP-Z01~Z13, OP-L01~L03, OP-P01~P05, OP-R01~R03, I-02a·I-04a·I-04b·I-04c)는 모두 A-8 또는 A-5 본문에 정의가 있고, 정의 없는 ID를 참조한 곳은 없다. 반합 범위(왕지 없는 짝도 일반 반합, OP-Z03)와 방합(세 지지, OP-Z04)은 C-10의 CS-109 '亥未 반합'과 D H-3-1에 같은 기준으로 적용되어 있다.
