import { evidenceRecordSchema } from '../contracts'
import type { EvidenceRecord } from '../contracts'

export const DOCUMENT_PINS = {
  A: { revision: 179, sha256: '4d918e24854c5d48724779e2167cd2d0fa9b7c6140afb5ff8c076f067c40d80c' },
  C: { revision: 215, sha256: '9e5b60a8346d4822a902d13e555dfc322431f016dfabf6f22c86390202c058f8' },
  D: { revision: 152, sha256: '0a1e991a6bc7f4c2514241732c17754d54ffa2eb46c4f95f91e524de164ebade' },
  '25-7': { revision: 16, sha256: '6abcb08af95b95cf2e94ed1314964035bff8e41dfd9e1623610b0f5182dd1cec' },
} as const

// Synchronous SHA-256 keeps existing fact producers synchronous in browser and SSR.
// This checks source identity; it is not an independent calendar/biography verification.
const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
const rotate = (x: number, n: number) => (x >>> n) | (x << (32 - n))
export function sourceSha256(text: string): string {
  const bytes = new TextEncoder().encode(text), length = Math.ceil((bytes.length + 9) / 64) * 64
  const data = new Uint8Array(length); data.set(bytes); data[bytes.length] = 0x80
  const view = new DataView(data.buffer), bitLength = bytes.length * 8
  view.setUint32(length - 8, Math.floor(bitLength / 0x100000000)); view.setUint32(length - 4, bitLength >>> 0)
  const h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
  const w = new Uint32Array(64)
  for (let offset = 0; offset < length; offset += 64) {
    for (let j = 0; j < 16; j++) w[j] = view.getUint32(offset + j * 4)
    for (let j = 16; j < 64; j++) {
      const a = w[j - 15], b = w[j - 2]
      w[j] = w[j - 16] + (rotate(a, 7) ^ rotate(a, 18) ^ (a >>> 3)) + w[j - 7] + (rotate(b, 17) ^ rotate(b, 19) ^ (b >>> 10))
    }
    let [a,b,c,d,e,f,g,z] = h
    for (let j = 0; j < 64; j++) {
      const t1 = (z + (rotate(e,6)^rotate(e,11)^rotate(e,25)) + ((e&f)^(~e&g)) + K[j] + w[j]) | 0
      const t2 = ((rotate(a,2)^rotate(a,13)^rotate(a,22)) + ((a&b)^(a&c)^(b&c))) | 0
      z=g; g=f; f=e; e=(d+t1)|0; d=c; c=b; b=a; a=(t1+t2)|0
    }
    for (const [j, v] of [a,b,c,d,e,f,g,z].entries()) h[j] = (h[j] + v) | 0
  }
  return h.map((v) => (v >>> 0).toString(16).padStart(8, '0')).join('')
}
export type PinnedDocument = { documentId: string; revision: number; path: string; sha256: string; text: string; rawEvidenceId: string }
/** Issues a receipt only for a checked clause/value in the pinned source bytes, not the entire system. */
export function verifyDocumentClaim(source: PinnedDocument, claim: { evidenceId: string; section: string; ruleId: string; quote: string; claimRef: string }): EvidenceRecord {
  const pin = DOCUMENT_PINS[source.documentId as keyof typeof DOCUMENT_PINS]
  if (!pin || source.revision !== pin.revision || source.sha256 !== pin.sha256
    || source.path !== `src/docs/source/${source.documentId}_rev${source.revision}.md`
    || !claim.section || !claim.ruleId || !claim.quote || !source.text.includes(claim.section)
    || !source.text.includes(claim.quote) || sourceSha256(source.text) !== source.sha256
    || !new RegExp(`^revision: ${source.revision}$`, 'm').test(source.text)) throw new TypeError(`Unverified document claim: ${source.documentId}/${claim.claimRef}`)
  const location = `line ${source.text.slice(0, source.text.indexOf(claim.quote)).split('\n').length}`
  return evidenceRecordSchema.parse({ evidenceId: claim.evidenceId, sourceType: 'source-document',
    sourceRef: { kind: 'source-document', document: { documentId: source.documentId, documentRevision: source.revision,
      path: source.path, section: claim.section, location } }, documentRevision: source.revision, ruleId: claim.ruleId,
    hash: { algorithm: 'SHA-256', value: source.sha256, hashTarget: source.path }, status: 'confirmed',
    verification: { claimRef: claim.claimRef, method: 'pinned-document-bytes-and-direct-clause-comparison-v1',
      checkedByRef: 'src/lib/judgment/systems/documentReceipt.ts:verifyDocumentClaim', basisEvidenceIds: [source.rawEvidenceId] },
    note: `Verified local document claim only: ${claim.quote}`, uncertaintyIds: [], usage: 'runtime-evidence' })
}
